let bg
let logo1
let logo2
let font1
let gambar1
let gambar2
let gambar3
let gambar4
let gambar5
let gambar6
let gambar7
let gambar8
let gambar9


'use strict';

let prey = [];
let predators = [];

let preyCount = 10;
let predatorCount = 10;

let predatorDeathRate = 0.005;
let preyLifeRate = 0.1;

function preload(){
  bg=loadImage("bg.jpg")
  logo1=loadImage("logoitera.png")
  logo2=loadImage("Logomath.png")
  font1=loadFont("font1.ttf")
  gambar1=loadImage("gambar1.png")
  gambar2=loadImage("gambar2.png")
  gambar3=loadImage("gambar3.png")
  gambar4=loadImage("gambar4.png")
  gambar5=loadImage("gambar5.jpeg")
  gambar6=loadImage("gambar6.jpeg")
  gambar7=loadImage("gambar7.jpeg")
  gambar8=loadImage("gambar8.jpeg")
  gambar9=loadImage("gambar9.jpeg")
}

function setup(){
  createCanvas(1250,2200)
  // Inisialisasi prey
  for (let i = 0; i < preyCount; i++) {
    prey.push(new Prey());
  }

  // Inisialisasi predator
  for (let i = 0; i < predatorCount; i++) {
    predators.push(new Predator());
  }
}

function draw(){
  background("white")
  noStroke()
  
  //background
  image(bg,0,0,1250,540);
  fill(5,60,50,200)
  rect(0,0,1250,550)
  rect(0,550,1250,3000)
  
  
  //logoitera
  image(logo1,1110,10,50,50)
  image(logo2,1165,7,58,58)
  
  
  textSize(30)
  textStyle(BOLD)
  fill("white")
  textFont(font1)
  text("SIMULASI PREY-PREDATOR",450,280)
  
  textSize(20)
  fill("white")
  text("Tugas Besar Simulasi dan Komputasi Matematika Kelompok F",350,300)
  
  textSize(20)
  fill("white")
  text("PEMODELAN PREY-PREDATOR",480,600)
  image(gambar1,340,480,200,200)

  text("Apakah kamu tahu apa  arti dari Prey-Predator? ",80,660)
  text("Prey adalah mangsa ,sedangkan Predator adalah pemangsa.Prey-Predator adalah interaksi antar spesies untuk ",80,690)
  text("mendapatkan makanannya dengan cara memangsa.Contohnya:Fox dan Rabbit.",80,710)
  
  text("Tahukah kamu bahwa Interaksi antara fox dan rabbit merupakan suatu Interaksi Prey-Predator??",80,750)
   image(gambar2,100,800,100,100)
  text("Seperti pada gambar disamping,Interaksi yang terjadi antara rabbit dan fox ",220,800) 
  text("adalah interaksi antar spesies atau dikenal dengan istilah predasi atau .",220,830)
  text("pemangsaaan Interaksi ini menyebabkan rabbit dimangsa oleh fox.Dalam predasi,",220,860)
  text("Predator atau fox mengambil energi/sumber makanan dari prey untuk tumbuh dan",220,890)
  text("Bereproduksi,Sedangkan Prey atau Rabbit merupakan organisme yang dikonsumsi predator.",220,920)
  text("Jika hal ini terjadi terus -menerus,maka Populasi dari Prey atay rabbit akan mengalami kepunahan.",80,950)
  text("Akan tetapi, setelah terjadi kepunahan pada populasi rabbit.maka terjadi kepunahan pada populasi fox.",80,980)
  text("Hal ini terjadi karena, jika populasi rabbit punah maka tidak ada rabbit yang di mangsa oleh fox.",80,1010)
  text("dan, Otomatis fox akan berkurang karena tidak adanya makanan yang akan dia mangsa.",80,1040)
  
  textSize(25)
  text("PERSAMAAN DIFERENSIAL",200,1110)
  text("Rabbit",150,1170)
  image(gambar3,250,1140)
  text("Fox",150,1240)
  image(gambar4,250,1210)
  
  text("PERSAMAAN BEDA",800,1110)
  image(gambar5,650,1140)
  image(gambar6,620,1210)
  
  text("KETERANGAN",250,1300)
  image(gambar7,150,1320)
  
  text("SIMULASI GRAFIK",850,1300)
  image(gambar8,650,1320,300,200)
  image(gambar9,1010,1330,200,150)
  
  text("GERAK SIMULASI",250,1600)
  //KODINGAN GERAK SIMULASI
  fill('white')
  rect(75,1620,500,500)
  
  
  
  
  
  text("INTERPRETASI",800,1600)
  textSize(15)
  text("Hasil Simulasi yang ditampilkan dengan memplot Populasi Rabbit dan Fox Terhadap waktu,",600,1620)
  text(" Menggunakan Parameter Paper.Dari Hasil Simulasi Grafik yang ditampilkan,warna kuning",595,1640)
  text("Melambangkan Jumlah dari Populasi Rabbit,Sedangkan grafik warna ungu melambangkan",600,1660)
  text("Populasi Fox.ketika Populasi rabbit meningkat maka Populasi fox juga meningkat.",600,1680)
  text("Tetapi,tidak akan melebihi dari populasi rabbit.Sebaliknya,jika Populasi Rabbit menurun",600,1700)
  text("maka populasi fox juga ikut menurun bahkan bisa lebih sedikit dari pada ",600,1720)
  text("Populasi Rabbit",600,1740)
  
  
  // Perbarui dan tampilkan predator
  for (let predator of predators) {
    predator.update();
    predator.constrain();
    predator.render();
  }

  // Perbarui dan tampilkan prey
  for (let p of prey) {
    p.update();
    p.constrain();
    p.render();

    // Deteksi kolisi dengan predator
    for (let predator of predators) {
      if (p.collide(predator)) {
        // Jika kolisi terjadi, tambahkan predator baru
        predators.push(new Predator());

        // Kurangi jumlah prey
        prey.splice(prey.indexOf(p), 1);
        break;
      }
    }
  }

  // Tingkat kematian predator
  for (let i = predators.length - 1; i >= 0; i--) {
    if (random() < predatorDeathRate) {
      predators.splice(i, 1);
    }
  }

  // Tingkat kehidupan prey
  for (let i = 0; i < preyCount; i++) {
    if (random() < preyLifeRate) {
      prey.push(new Prey());
    }
  }  
}

class Prey {
  constructor() {
    this.pos = createVector(random(75, 575), random(1620, 2120));
    this.vel = createVector(random(-1, 1), random(-1, 1));
    this.acc = createVector(0, 0);
    this.maxSpeed = 2;
    this.radius = 5;
  }

  update() {
    this.vel.add(this.acc);
    this.vel.limit(this.maxSpeed);
    this.pos.add(this.vel);
    this.acc.mult(0);
  }

  render() {
    push();
    translate(this.pos.x, this.pos.y);
    noStroke();
    fill(0, 255, 0);
    ellipse(0, 0, this.radius * 2);
    pop();
  }

  collide(predator) {
    let d = dist(this.pos.x, this.pos.y, predator.pos.x, predator.pos.y);
    return d < this.radius + predator.radius;
  }

  constrain() {
    if (this.pos.x < 75) this.pos.x = 75;
    if (this.pos.x > 575) this.pos.x = 575;
    if (this.pos.y < 1620) this.pos.y = 1620;
    if (this.pos.y > 2120) this.pos.y = 2120;
  }
}

class Predator {
  constructor() {
    this.pos = createVector(random(75, 575), random(1620, 2120));
    this.vel = createVector(random(-1, 1), random(-1, 1));
    this.acc = createVector(0, 0);
    this.maxSpeed = 4;
    this.radius = 10;
  }

  update() {
    this.vel.add(this.acc);
    this.vel.limit(this.maxSpeed);
    this.pos.add(this.vel);
    this.acc.mult(0);
  }

  render() {
    push();
    translate(this.pos.x, this.pos.y);
    noStroke();
    fill(255, 0, 0);
    ellipse(0, 0, this.radius * 2);
    pop();
  }

  constrain() {
    if (this.pos.x < 75) this.pos.x = 75;
    if (this.pos.x > 575) this.pos.x = 575;
    if (this.pos.y < 1620) this.pos.y = 1620;
    if (this.pos.y > 2120) this.pos.y = 2120;
  }
}

// Event listener untuk mengubah tingkat kematian predator
function setPredatorDeathRate(value) {
  predatorDeathRate = value;
}

// Event listener untuk mengubah tingkat kehidupan prey
function setPreyLifeRate(value) {
  preyLifeRate = value;
}